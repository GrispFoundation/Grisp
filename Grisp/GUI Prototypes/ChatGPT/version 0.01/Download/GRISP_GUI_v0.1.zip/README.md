# GRISP GUI v0.1

Delphi 13 VCL prototype of the simplified GRISP GUI.

## Design focus

- Central chat workspace
- Optional collapsible Think section
- Chat input/send area
- Session history
- Collapsible resource Explorer
- Read / Write / Execute permissions
- Plan / Work Items inside the chat workspace
- Dark blue/cyan futuristic appearance
- No CPU/GPU/network/storage dashboard clutter
- No third-party dependencies

## Build

Open `GRISP.GUI.dpr` in Delphi 13 and build Win32 or Win64.

## Keyboard

F2       Explorer
F3       Sessions
F4       Think
Ctrl+N   New chat

## Architecture

This prototype deliberately keeps the visual controls in a small number of Delphi units. The demo data can later be replaced by the real GRISP session/resource/event model.

## ZIP layout

The ZIP is intentionally flat. There is no root directory or version directory inside it.
