# GRISP GUI v0.1.1

Delphi 13 VCL prototype of the simplified GRISP GUI.

## v0.1.1 compiler fixes

- Added `Winapi.Messages` for `TMessage` and control-message handlers.
- Replaced `RGB(...)` calls used in constant declarations with compile-time `TColor` constants.
- Removed undeclared custom constructors from inherited session/status controls.
- Replaced the `DrawText` call that passed the `ClientRect` property as a `var` parameter with direct canvas text positioning.
- Removed the `IfThen` layout dependency from the session panel positioning.

## Design focus

- Central chat workspace
- Optional collapsible Think section
- Chat input/send area
- Session history
- Collapsible resource Explorer
- Read / Write / Execute permissions
- Plan / Work Items inside the chat workspace
- Dark blue/cyan futuristic appearance
- No CPU/GPU/network/storage dashboard clutter
- No third-party dependencies

## Build

Open `GRISP.GUI.dpr` in Delphi 13 and build Win32 or Win64.

## Keyboard

F2       Explorer
F3       Sessions
F4       Think
Ctrl+N   New chat

## ZIP layout

The ZIP is intentionally flat. There is no root directory or version directory inside it.
