object GrispMainForm: TGrispMainForm
  Left = 0
  Top = 0
  Caption = 'GRISP OS'
  ClientHeight = 900
  ClientWidth = 1450
  Color = 1116674
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Segoe UI'
  Font.Style = []
  OldCreateOrder = False
  BorderStyle = bsNone
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
end
