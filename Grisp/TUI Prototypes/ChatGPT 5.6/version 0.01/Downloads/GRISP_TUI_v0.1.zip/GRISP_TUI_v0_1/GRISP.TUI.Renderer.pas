unit GRISP.TUI.Renderer;

interface

uses
    System.SysUtils,
    System.Math,
    GRISP.TUI.Console,
    GRISP.TUI.Model;

type
    TGrispPanelMode = (gpmNone, gpmExplorer, gpmSessions);

    TGrispTUIRenderer = class
    private
        mConsole: TGrispConsole;
        mModel: TGrispModel;
        mExplorerVisible: Boolean;
        mSessionsVisible: Boolean;
        mThinkVisible: Boolean;
        mPlanVisible: Boolean;
        mPanelWidth: Integer;
        mHeaderHeight: Integer;
        mFooterHeight: Integer;
        procedure DrawBorder(ParaX, ParaY, ParaWidth, ParaHeight: Integer; const ParaTitle: string);
        procedure DrawHeader;
        procedure DrawFooter;
        procedure DrawExplorer(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
        procedure DrawSessions(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
        procedure DrawChat(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
        procedure DrawMessage(ParaX, var ParaY: Integer; ParaWidth: Integer; const ParaMessage: TGrispMessage);
        procedure DrawPlan(ParaX, var ParaY: Integer; ParaWidth: Integer);
        procedure DrawThink(ParaX, var ParaY: Integer; ParaWidth: Integer);
        procedure DrawInput(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
        function FitText(const ParaText: string; const ParaWidth: Integer): string;
        function TrustGlyph(const ParaTrust: Integer): string;
        function PermissionGlyph(const ParaAllowed: Boolean): string;
        procedure DrawTextBlock(ParaX, var ParaY: Integer; ParaWidth: Integer; const ParaLines: TArray<string>);
    public
        constructor Create(ParaConsole: TGrispConsole; ParaModel: TGrispModel);
        procedure Render;
        procedure ToggleExplorer;
        procedure ToggleSessions;
        procedure ToggleThink;
        procedure TogglePlan;
        function ExplorerVisible: Boolean;
        function SessionsVisible: Boolean;
        function ThinkVisible: Boolean;
        function PlanVisible: Boolean;
    end;

implementation

const
    C_RESET = #27'[0m';
    C_BLUE = #27'[38;5;39m';
    C_CYAN = #27'[38;5;51m';
    C_DIM = #27'[38;5;67m';
    C_WHITE = #27'[38;5;255m';
    C_GREEN = #27'[38;5;46m';
    C_YELLOW = #27'[38;5;220m';
    C_RED = #27'[38;5;203m';
    C_BG = #27'[48;5;17m';

constructor TGrispTUIRenderer.Create(ParaConsole: TGrispConsole; ParaModel: TGrispModel);
begin
    inherited Create;
    mConsole := ParaConsole;
    mModel := ParaModel;
    mExplorerVisible := True;
    mSessionsVisible := True;
    mThinkVisible := False;
    mPlanVisible := True;
    mPanelWidth := 28;
    mHeaderHeight := 3;
    mFooterHeight := 2;
end;

procedure TGrispTUIRenderer.DrawBorder(ParaX, ParaY, ParaWidth, ParaHeight: Integer; const ParaTitle: string);
var
    vTop: string;
    vMiddle: string;
    vBottom: string;
    vIndex: Integer;
begin
    if ParaWidth < 2 then
        Exit;
    vTop := '┌' + StringOfChar('─', ParaWidth - 2) + '┐';
    vBottom := '└' + StringOfChar('─', ParaWidth - 2) + '┘';
    vMiddle := '│' + StringOfChar(' ', ParaWidth - 2) + '│';
    if ParaTitle <> '' then
    begin
        vTop := '┌─ ' + ParaTitle + ' ' + StringOfChar('─', Max(0, ParaWidth - 5 - Length(ParaTitle))) + '┐';
    end;
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + vTop + C_RESET);
    for vIndex := 1 to ParaHeight - 2 do
        mConsole.WriteAt(ParaX, ParaY + vIndex, C_BLUE + vMiddle + C_RESET);
    mConsole.WriteAt(ParaX, ParaY + ParaHeight - 1, C_BLUE + vBottom + C_RESET);
end;

procedure TGrispTUIRenderer.DrawHeader;
var
    vWidth: Integer;
    vLine: string;
begin
    vWidth := mConsole.Width;
    vLine := '╔' + StringOfChar('═', Max(0, vWidth - 2)) + '╗';
    mConsole.WriteAt(0, 0, C_BLUE + vLine + C_RESET);
    mConsole.WriteAt(2, 1, C_CYAN + '◈ GRISP OS' + C_RESET + C_DIM + '   Deterministic AI Runtime' + C_RESET);
    mConsole.WriteAt(36, 1, C_CYAN + '[ CHAT ]' + C_RESET + '  [ WORK ]  [ KNOWLEDGE ]');
    mConsole.WriteAt(Max(0, vWidth - 18), 1, C_GREEN + '● READY' + C_RESET);
    mConsole.WriteAt(0, 2, C_BLUE + '╠' + StringOfChar('═', Max(0, vWidth - 2)) + '╣' + C_RESET);
end;

procedure TGrispTUIRenderer.DrawFooter;
var
    vWidth: Integer;
    vY: Integer;
    vLine: string;
begin
    vWidth := mConsole.Width;
    vY := mConsole.Height - 2;
    vLine := '╠' + StringOfChar('═', Max(0, vWidth - 2)) + '╣';
    mConsole.WriteAt(0, vY, C_BLUE + vLine + C_RESET);
    mConsole.WriteAt(2, vY + 1,
        C_DIM + 'GRISP:/Workspace' + C_RESET +
        '   ' + C_CYAN + '[F2] Explorer' + C_RESET +
        '  [F3] Sessions  [F4] Think  [F5] Plan  [Ctrl+N] New  [ESC] Quit');
end;

procedure TGrispTUIRenderer.DrawExplorer(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
var
    vIndex: Integer;
    vResource: TGrispResource;
    vLine: string;
    vIndent: string;
    vY: Integer;
    vTrustColor: string;
begin
    DrawBorder(ParaX, ParaY, ParaWidth, ParaHeight, 'EXPLORER');
    mConsole.WriteAt(ParaX + 2, ParaY + 1, C_DIM + 'GRISP:/' + C_RESET);

    for vIndex := 0 to High(mModel.Resources) do
    begin
        if ParaY + 3 + vIndex >= ParaY + ParaHeight - 1 then
            Break;
        vResource := mModel.Resources[vIndex];
        vIndent := StringOfChar(' ', vResource.Depth * 2);
        if vResource.IsFolder then
        begin
            if vResource.Expanded then
                vLine := vIndent + '▾ ' + '■ ' + vResource.Name
            else
                vLine := vIndent + '▸ ' + '■ ' + vResource.Name;
        end
        else
            vLine := vIndent + '  · ' + vResource.Name;
        if vIndex = mModel.SelectedResource then
            vLine := C_WHITE + C_BG + ' ' + FitText(vLine, ParaWidth - 8) + ' ' + C_RESET;
        else
            vLine := C_WHITE + FitText(vLine, ParaWidth - 3) + C_RESET;
        mConsole.WriteAt(ParaX + 1, ParaY + 2 + vIndex, vLine);
    end;

    if ParaHeight > 12 then
    begin
        vY := ParaY + ParaHeight - 5;
        mConsole.WriteAt(ParaX + 2, vY, C_DIM + 'PERMISSIONS' + C_RESET);
        vResource := mModel.Resources[mModel.SelectedResource];
        mConsole.WriteAt(ParaX + 2, vY + 1, 'R  ' + PermissionGlyph(vResource.ReadAllowed) + '  Read');
        mConsole.WriteAt(ParaX + 2, vY + 2, 'W  ' + PermissionGlyph(vResource.WriteAllowed) + '  Write');
        mConsole.WriteAt(ParaX + 2, vY + 3, 'X  ' + PermissionGlyph(vResource.ExecuteAllowed) + '  Execute');
    end;
end;

procedure TGrispTUIRenderer.DrawSessions(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
var
    vIndex: Integer;
    vSession: TGrispSession;
    vLine: string;
begin
    DrawBorder(ParaX, ParaY, ParaWidth, ParaHeight, 'SESSIONS');
    for vIndex := 0 to High(mModel.Sessions) do
    begin
        if ParaY + 2 + vIndex * 2 >= ParaY + ParaHeight - 1 then
            Break;
        vSession := mModel.Sessions[vIndex];
        vLine := FitText(vSession.Title, ParaWidth - 4);
        if vIndex = mModel.SelectedSession then
            mConsole.WriteAt(ParaX + 1, ParaY + 1 + vIndex * 2, C_WHITE + C_BG + ' ' + vLine + ' ' + C_RESET)
        else
            mConsole.WriteAt(ParaX + 2, ParaY + 1 + vIndex * 2, C_CYAN + vLine + C_RESET);
        mConsole.WriteAt(ParaX + 3, ParaY + 2 + vIndex * 2, C_DIM + vSession.DateTimeText + C_RESET);
    end;
end;

procedure TGrispTUIRenderer.DrawChat(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
var
    vY: Integer;
    vMessage: TGrispMessage;
    vIndex: Integer;
    vInputHeight: Integer;
    vPlanHeight: Integer;
begin
    DrawBorder(ParaX, ParaY, ParaWidth, ParaHeight, 'SESSION: ' + mModel.Sessions[mModel.SelectedSession].Title);
    vY := ParaY + 2;
    vInputHeight := 4;

    for vIndex := 0 to High(mModel.Messages) do
    begin
        vMessage := mModel.Messages[vIndex];
        DrawMessage(ParaX + 2, vY, ParaWidth - 4, vMessage);
        Inc(vY);
    end;

    if mPlanVisible then
    begin
        vPlanHeight := 6;
        DrawPlan(ParaX + 2, vY, ParaWidth - 4);
        Inc(vY, vPlanHeight);
    end;

    if mThinkVisible then
    begin
        DrawThink(ParaX + 2, vY, ParaWidth - 4);
        Inc(vY, 5);
    end;

    DrawInput(ParaX + 2, ParaY + ParaHeight - vInputHeight - 1, ParaWidth - 4, vInputHeight);
end;

procedure TGrispTUIRenderer.DrawMessage(ParaX: Integer; var ParaY: Integer; ParaWidth: Integer; const ParaMessage: TGrispMessage);
var
    vIndex: Integer;
    vPrefix: string;
    vColor: string;
begin
    if ParaMessage.Role = 'YOU' then
    begin
        vPrefix := 'YOU';
        vColor := C_WHITE;
    end
    else
    begin
        vPrefix := 'GRISP';
        vColor := C_CYAN;
    end;

    mConsole.WriteAt(ParaX, ParaY, vColor + vPrefix + C_RESET + C_DIM + '  ' + ParaMessage.TimeText + C_RESET);
    Inc(ParaY);
    for vIndex := 0 to High(ParaMessage.Lines) do
    begin
        mConsole.WriteAt(ParaX, ParaY, C_WHITE + '│ ' + FitText(ParaMessage.Lines[vIndex], ParaWidth - 3) + C_RESET);
        Inc(ParaY);
    end;
    Inc(ParaY);
end;

procedure TGrispTUIRenderer.DrawPlan(ParaX: Integer; var ParaY: Integer; ParaWidth: Integer);
var
    vIndex: Integer;
    vItem: TGrispPlanItem;
    vMark: string;
    vColor: string;
begin
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + '┌─ PLAN ' + StringOfChar('─', Max(0, ParaWidth - 8)) + '┐' + C_RESET);
    Inc(ParaY);
    for vIndex := 0 to High(mModel.Plan) do
    begin
        vItem := mModel.Plan[vIndex];
        if vItem.State = 'DONE' then
        begin
            vMark := '✓';
            vColor := C_GREEN;
        end
        else if vItem.State = 'ACTIVE' then
        begin
            vMark := '>'; vColor := C_YELLOW;
        end
        else
        begin
            vMark := ' '; vColor := C_DIM;
        end;
        mConsole.WriteAt(ParaX, ParaY, '│ ' + vColor + vMark + C_RESET + ' ' + FitText(vItem.Title, ParaWidth - 7) + ' ' + C_DIM + vItem.State + C_RESET);
        Inc(ParaY);
    end;
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + '└' + StringOfChar('─', Max(0, ParaWidth - 2)) + '┘' + C_RESET);
    Inc(ParaY);
end;

procedure TGrispTUIRenderer.DrawThink(ParaX: Integer; var ParaY: Integer; ParaWidth: Integer);
begin
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + '┌─ THINK (visible prototype) ' + StringOfChar('─', Max(0, ParaWidth - 29)) + '┐' + C_RESET);
    Inc(ParaY);
    mConsole.WriteAt(ParaX, ParaY, C_DIM + '│ > Analyze architecture' + C_RESET); Inc(ParaY);
    mConsole.WriteAt(ParaX, ParaY, C_DIM + '│ > Identify relevant components' + C_RESET); Inc(ParaY);
    mConsole.WriteAt(ParaX, ParaY, C_DIM + '│ > Construct response' + C_RESET); Inc(ParaY);
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + '└' + StringOfChar('─', Max(0, ParaWidth - 2)) + '┘' + C_RESET); Inc(ParaY);
end;

procedure TGrispTUIRenderer.DrawInput(ParaX, ParaY, ParaWidth, ParaHeight: Integer);
begin
    mConsole.WriteAt(ParaX, ParaY, C_BLUE + '┌─ MESSAGE ' + StringOfChar('─', Max(0, ParaWidth - 12)) + '┐' + C_RESET);
    mConsole.WriteAt(ParaX, ParaY + 1, '│ ' + C_WHITE + FitText(mModel.InputText + '▌', ParaWidth - 4) + C_RESET);
    mConsole.WriteAt(ParaX, ParaY + 2, C_BLUE + '└' + StringOfChar('─', Max(0, ParaWidth - 2)) + '┘' + C_RESET);
end;

procedure TGrispTUIRenderer.Render;
var
    vWidth: Integer;
    vHeight: Integer;
    vContentY: Integer;
    vContentHeight: Integer;
    vLeftWidth: Integer;
    vChatX: Integer;
    vChatWidth: Integer;
begin
    mConsole.BeginFrame;
    vWidth := mConsole.Width;
    vHeight := mConsole.Height;

    if vWidth < 80 then
    begin
        mConsole.WriteAt(0, 0, C_RED + 'GRISP TUI requires at least 80 columns.' + C_RESET);
        mConsole.EndFrame;
        Exit;
    end;

    DrawHeader;
    DrawFooter;

    vContentY := mHeaderHeight;
    vContentHeight := vHeight - mHeaderHeight - mFooterHeight;

    if mExplorerVisible or mSessionsVisible then
    begin
        vLeftWidth := Min(mPanelWidth, vWidth div 3);
        vChatX := vLeftWidth + 1;
        vChatWidth := vWidth - vChatX;
        if mExplorerVisible then
            DrawExplorer(0, vContentY, vLeftWidth, vContentHeight)
        else
            DrawSessions(0, vContentY, vLeftWidth, vContentHeight);
    end
    else
    begin
        vChatX := 0;
        vChatWidth := vWidth;
    end;

    DrawChat(vChatX, vContentY, vChatWidth, vContentHeight);
    mConsole.EndFrame;
end;

function TGrispTUIRenderer.FitText(const ParaText: string; const ParaWidth: Integer): string;
begin
    if ParaWidth <= 0 then
        Exit('');
    if Length(ParaText) <= ParaWidth then
        Exit(ParaText);
    Result := Copy(ParaText, 1, Max(0, ParaWidth - 1)) + '…';
end;

function TGrispTUIRenderer.TrustGlyph(const ParaTrust: Integer): string;
begin
    if ParaTrust >= 70 then
        Result := C_GREEN + '●' + C_RESET
    else if ParaTrust >= 40 then
        Result := C_YELLOW + '●' + C_RESET
    else
        Result := C_RED + '●' + C_RESET;
end;

function TGrispTUIRenderer.PermissionGlyph(const ParaAllowed: Boolean): string;
begin
    if ParaAllowed then
        Result := C_GREEN + '✓' + C_RESET
    else
        Result := C_RED + '×' + C_RESET;
end;

procedure TGrispTUIRenderer.DrawTextBlock(ParaX: Integer; var ParaY: Integer; ParaWidth: Integer; const ParaLines: TArray<string>);
var
    vIndex: Integer;
begin
    for vIndex := 0 to High(ParaLines) do
    begin
        mConsole.WriteAt(ParaX, ParaY, FitText(ParaLines[vIndex], ParaWidth));
        Inc(ParaY);
    end;
end;

procedure TGrispTUIRenderer.ToggleExplorer;
begin
    mExplorerVisible := not mExplorerVisible;
    if mExplorerVisible then
        mSessionsVisible := False;
end;

procedure TGrispTUIRenderer.ToggleSessions;
begin
    mSessionsVisible := not mSessionsVisible;
    if mSessionsVisible then
        mExplorerVisible := False;
end;

procedure TGrispTUIRenderer.ToggleThink;
begin
    mThinkVisible := not mThinkVisible;
end;

procedure TGrispTUIRenderer.TogglePlan;
begin
    mPlanVisible := not mPlanVisible;
end;

function TGrispTUIRenderer.ExplorerVisible: Boolean;
begin
    Result := mExplorerVisible;
end;

function TGrispTUIRenderer.SessionsVisible: Boolean;
begin
    Result := mSessionsVisible;
end;

function TGrispTUIRenderer.ThinkVisible: Boolean;
begin
    Result := mThinkVisible;
end;

function TGrispTUIRenderer.PlanVisible: Boolean;
begin
    Result := mPlanVisible;
end;

end.
