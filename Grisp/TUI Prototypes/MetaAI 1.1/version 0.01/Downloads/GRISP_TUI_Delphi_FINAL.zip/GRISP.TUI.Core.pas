unit GRISP.TUI.Core;

interface

uses Winapi.Windows, System.SysUtils;

type
  TGRISPColors = record
  const
    RESET       = #27'[0m';
    CYAN        = #27'[38;2;0;212;255m';
    CYAN_DIM    = #27'[38;2;30;58;107m';
    CYAN_BG     = #27'[48;2;15;42;90m';
    WHITE       = #27'[38;2;214;228;255m';
    DIM         = #27'[38;2;107;139;184m';
    GREEN       = #27'[38;2;0;255;136m';
    GREEN_BG    = #27'[48;2;0;60;30m';
    RED         = #27'[38;2;255;68;68m';
    AMBER       = #27'[38;2;255;170;0m';
    BLUE        = #27'[38;2;79;124;255m';
    BG_DARK     = #27'[48;2;5;11;28m';
    BG_PANEL    = #27'[48;2;14;27;51m';
  end;

  TTUIRect = record
    X, Y, W, H: Integer;
    constructor Create(AX, AY, AW, AH: Integer);
  end;

  TTUIColor = string;

procedure EnableANSI;
procedure ClearScreen;
procedure HideCursor;
procedure ShowCursor;
procedure GotoXY(X, Y: Integer);
procedure SetColor(const Color: string);
procedure ResetColor;
procedure DrawBox(const R: TTUIRect; const Title: string; Focused: Boolean);
procedure DrawHLine(X, Y, Len: Integer; Focused: Boolean);
procedure DrawText(X, Y: Integer; const Text: string; const Color: string = '');
procedure DrawRWX(X, Y: Integer; Perms: TPermissions);

implementation

constructor TTUIRect.Create(AX, AY, AW, AH: Integer);
begin
  X := AX; Y := AY; W := AW; H := AH;
end;

procedure EnableANSI;
var
  hOut: THandle;
  dwMode: DWORD;
begin
  hOut := GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleMode(hOut, dwMode);
  dwMode := dwMode or $0004; // ENABLE_VIRTUAL_TERMINAL_PROCESSING
  SetConsoleMode(hOut, dwMode);
  SetConsoleOutputCP(CP_UTF8);
  SetConsoleCP(CP_UTF8);
end;

procedure ClearScreen;
begin
  Write(#27'[2J' + #27'[H'); // Clear + Home
end;

procedure HideCursor;
begin
  Write(#27'[?25l');
end;

procedure ShowCursor;
begin
  Write(#27'[?25h');
end;

procedure GotoXY(X, Y: Integer);
begin
  Write(Format(#27'[%d;%dH', [Y, X]));
end;

procedure SetColor(const Color: string);
begin
  Write(Color);
end;

procedure ResetColor;
begin
  Write(TGRISPColors.RESET);
end;

procedure DrawBox(const R: TTUIRect; const Title: string; Focused: Boolean);
var
  i: Integer;
  borderColor: string;
  tl, tr, bl, br, h, v: string;
begin
  if Focused then
    borderColor := TGRISPColors.CYAN
  else
    borderColor := TGRISPColors.CYAN_DIM;

  // Unicode box drawing - werkt in Windows Terminal / nieuwe cmd.exe met UTF8
  tl := '┌'; tr := '┐'; bl := '└'; br := '┘'; h := '─'; v := '│';

  SetColor(borderColor);
  // Top
  GotoXY(R.X, R.Y);
  Write(tl);
  for i := 1 to R.W - 2 do Write(h);
  Write(tr);

  // Sides
  for i := 1 to R.H - 2 do
  begin
    GotoXY(R.X, R.Y + i);
    Write(v);
    GotoXY(R.X + R.W - 1, R.Y + i);
    Write(v);
  end;

  // Bottom
  GotoXY(R.X, R.Y + R.H - 1);
  Write(bl);
  for i := 1 to R.W - 2 do Write(h);
  Write(br);

  // Title
  if Title <> '' then
  begin
    GotoXY(R.X + 2, R.Y);
    SetColor(TGRISPColors.WHITE);
    Write(' ' + Title + ' ');
    SetColor(borderColor);
  end;
  ResetColor;
end;

procedure DrawHLine(X, Y, Len: Integer; Focused: Boolean);
var
  i: Integer;
  c: string;
begin
  if Focused then c := TGRISPColors.CYAN else c := TGRISPColors.CYAN_DIM;
  SetColor(c);
  GotoXY(X, Y);
  for i := 1 to Len do Write('─');
  ResetColor;
end;

procedure DrawText(X, Y: Integer; const Text: string; const Color: string = '');
begin
  GotoXY(X, Y);
  if Color <> '' then SetColor(Color);
  Write(Text);
  if Color <> '' then ResetColor;
end;

begin
  // Niet gebruikt - echte versie hieronder
  Result := '';
end;

procedure DrawRWX(X, Y: Integer; Perms: TPermissions);
var
  hasR, hasW, hasX: Boolean;
begin
  hasR := 0 in Perms;
  hasW := 1 in Perms;
  hasX := 2 in Perms;

  GotoXY(X, Y);
  if hasR then SetColor(TGRISPColors.BLUE) else SetColor(TGRISPColors.DIM);
  Write('R ');
  if hasW then SetColor(TGRISPColors.GREEN) else SetColor(TGRISPColors.DIM);
  Write('W ');
  if hasX then SetColor(TGRISPColors.AMBER) else SetColor(TGRISPColors.DIM);
  Write('X');
  ResetColor;
end;

end.
