unit GRISP.TUI.Data;

interface

uses System.SysUtils;

type
  TPermission = (permRead, permWrite, permExecute);
  TPermissions = set of TPermission;

  TResourceItem = record
    Name: string;
    IsFolder: Boolean;
    Level: Integer;
    Perms: TPermissions;
    Trust: Integer;
    Expanded: Boolean;
    constructor Create(const AName: string; ALevel: Integer; AIsFolder: Boolean; APerms: TPermissions; ATrust: Integer);
  end;

  TSessionItem = record
    Subject: string;
    Day: string;
    TimeStr: string;
    MsgCount: Integer;
    IsActive: Boolean;
  end;

  TPlanStep = record
    Title: string;
    Status: Integer; // 0=Pending,1=InProgress,2=Completed
  end;

  TWorkItem = record
    Title: string;
    Priority: Integer; // 0=Low,1=Med,2=High
  end;

  TChatRole = (crUser, crAssistant, crSystem);

  TChatMessage = record
    Role: TChatRole;
    Text: string;
    TimeStr: string;
    Thinking: string;
    HasPlan: Boolean;
  end;

  TFocusedPanel = (fpExplorer, fpSessions, fpChat, fpPlan, fpThink, fpInput);

implementation

constructor TResourceItem.Create(const AName: string; ALevel: Integer; AIsFolder: Boolean; APerms: TPermissions; ATrust: Integer);
begin
  Name := AName;
  Level := ALevel;
  IsFolder := AIsFolder;
  Perms := APerms;
  Trust := ATrust;
  Expanded := True;
end;

end.
