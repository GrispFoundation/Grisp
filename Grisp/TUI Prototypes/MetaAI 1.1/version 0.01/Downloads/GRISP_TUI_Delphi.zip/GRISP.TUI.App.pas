unit GRISP.TUI.App;

interface

uses
  Winapi.Windows, System.SysUtils, System.Classes, System.Generics.Collections,
  GRISP.TUI.Data, GRISP.TUI.Core;

type
  TGRISPTUIApp = class
  private
    FWidth, FHeight: Integer;
    FFocused: TFocusedPanel;
    FExplorer: TArray<TResourceItem>;
    FSessions: TArray<TSessionItem>;
    FChat: TArray<TChatMessage>;
    FPlan: TArray<TPlanStep>;
    FWorkItems: TArray<TWorkItem>;
    FSelExplorer: Integer;
    FSelSession: Integer;
    FSelPlan: Integer;
    FThinkExpanded: Boolean;
    FLeftCollapsed: Boolean;
    FRightCollapsed: Boolean;
    FInputBuffer: string;
    FRunning: Boolean;

    procedure InitData;
    procedure GetConsoleSize;
    procedure DrawAll;
    procedure DrawHeader;
    procedure DrawExplorer;
    procedure DrawSessions;
    procedure DrawChat;
    procedure DrawPlan;
    procedure DrawInput;
    procedure DrawFooter;
    procedure HandleInput;
    function ReadKey: Word; // returns virtual key code

    procedure ToggleLeft;
    procedure ToggleRight;
    procedure ToggleThink;
    procedure MoveSelection(Delta: Integer);
    procedure SendCurrentInput;
  public
    constructor Create;
    procedure Run;
  end;

implementation

constructor TGRISPTUIApp.Create;
begin
  inherited Create;
  EnableANSI;
  FFocused := fpChat;
  FSelExplorer := 0;
  FSelSession := 0;
  FSelPlan := 0;
  FThinkExpanded := True;
  FLeftCollapsed := False;
  FRightCollapsed := False;
  FInputBuffer := '';
  FRunning := True;
  InitData;
end;

procedure TGRISPTUIApp.InitData;
begin
  // Explorer - met R W X permissies zoals gevraagd
  SetLength(FExplorer, 12);
  FExplorer[0] := TResourceItem.Create('GRISP', 0, True, [0,1,2], 90);
  FExplorer[1] := TResourceItem.Create('Local', 1, True, [0,1,2], 85);
  FExplorer[2] := TResourceItem.Create('Projects', 2, True, [1], 80);
  FExplorer[3] := TResourceItem.Create('GRISP', 3, True, [0,1,2], 85);
  FExplorer[4] := TResourceItem.Create('src', 4, False, [0,1,2], 85);
  FExplorer[5] := TResourceItem.Create('tests', 4, False, [0,1,2], 80);
  FExplorer[6] := TResourceItem.Create('docs', 4, False, [0,1,2], 75);
  FExplorer[7] := TResourceItem.Create('MME-Registry', 4, False, [0,1,2], 80);
  FExplorer[8] := TResourceItem.Create('Agent-Network', 4, False, [0,1,2], 80);
  FExplorer[9] := TResourceItem.Create('Data', 2, True, [0,1], 70);
  FExplorer[10] := TResourceItem.Create('Models', 1, True, [0,1], 70);
  FExplorer[11] := TResourceItem.Create('Trash', 1, True, [0,1], 30);

  // Sessions - onderwerp + dag + tijdstip
  SetLength(FSessions, 5);
  FSessions[0].Subject := 'Project setup and architecture';
  FSessions[0].Day := 'Today'; FSessions[0].TimeStr := '14:12'; FSessions[0].MsgCount := 12; FSessions[0].IsActive := True;
  FSessions[1].Subject := 'Data model discussion';
  FSessions[1].Day := 'Today'; FSessions[1].TimeStr := '11:45'; FSessions[1].MsgCount := 8;
  FSessions[2].Subject := 'Bug investigation';
  FSessions[2].Day := '21 Sep'; FSessions[2].TimeStr := '16:20'; FSessions[2].MsgCount := 5;
  FSessions[3].Subject := 'Feature planning';
  FSessions[3].Day := '20 Sep'; FSessions[3].TimeStr := '10:10'; FSessions[3].MsgCount := 22;
  FSessions[4].Subject := 'General questions';
  FSessions[4].Day := '19 Sep'; FSessions[4].TimeStr := '14:33'; FSessions[4].MsgCount := 3;

  // Chat
  SetLength(FChat, 3);
  FChat[0].Role := crAssistant; FChat[0].TimeStr := '14:12'; FChat[0].Text := 'Hello Alex, How can I help you with GRISP today?';
  FChat[1].Role := crUser; FChat[1].TimeStr := '14:12'; FChat[1].Text := 'Can you help me analyze the GRISP architecture and explain the main components?';
  FChat[2].Role := crAssistant; FChat[2].TimeStr := '14:12';
  FChat[2].Text := 'Sure! GRISP is deterministic, graph-based:' + sLineBreak +
                   '1. SIR (Source Intermediate)' + sLineBreak +
                   '2. Planner - creates plan' + sLineBreak +
                   '3. Evaluator - executes' + sLineBreak +
                   '4. Validator - checks' + sLineBreak +
                   '5. EIR - optimized' + sLineBreak +
                   '6. Runtime - deterministic' + sLineBreak +
                   '7. WorldState - state';
  FChat[2].Thinking := 'Analyzing GRISP architecture from docs...' + sLineBreak +
                      'Identified 7 main components...' + sLineBreak +
                      'Preparing structured explanation...';
  FChat[2].HasPlan := True;

  // Plan
  SetLength(FPlan, 4);
  FPlan[0].Title := 'Analyze architecture'; FPlan[0].Status := 2;
  FPlan[1].Title := 'Review component details'; FPlan[1].Status := 1;
  FPlan[2].Title := 'Create diagram'; FPlan[2].Status := 0;
  FPlan[3].Title := 'Update documentation'; FPlan[3].Status := 0;

  // Work Items
  SetLength(FWorkItems, 4);
  FWorkItems[0].Title := 'Implement GRISP runtime'; FWorkItems[0].Priority := 2;
  FWorkItems[1].Title := 'Add graph visualization'; FWorkItems[1].Priority := 1;
  FWorkItems[2].Title := 'Write unit tests'; FWorkItems[2].Priority := 1;
  FWorkItems[3].Title := 'Update LSBP integration'; FWorkItems[3].Priority := 0;
end;

procedure TGRISPTUIApp.GetConsoleSize;
var
  info: TConsoleScreenBufferInfo;
  h: THandle;
begin
  h := GetStdHandle(STD_OUTPUT_HANDLE);
  GetConsoleScreenBufferInfo(h, info);
  FWidth := info.srWindow.Right - info.srWindow.Left + 1;
  FHeight := info.srWindow.Bottom - info.srWindow.Top + 1;
  if FWidth < 100 then FWidth := 120;
  if FHeight < 30 then FHeight := 35;
end;

procedure TGRISPTUIApp.DrawAll;
begin
  GetConsoleSize;
  ClearScreen;
  HideCursor;
  DrawHeader;
  DrawExplorer;
  DrawSessions;
  DrawChat;
  DrawPlan;
  DrawInput;
  DrawFooter;
  ShowCursor;
end;

procedure TGRISPTUIApp.DrawHeader;
begin
  DrawBox(TTUIRect.Create(1,1,FWidth,3), ' GRISP OS TUI - Deterministic AI Runtime - Agent: Alex Ready - ' + FormatDateTime('hh:nn', Now), True);
  DrawText(3, 2, '[F1]Explorer [F2]Sessions [F3]Chat [F4]Plan [F5]Think [F10]Quit  Focus: ' + IntToStr(Ord(FFocused)), TGRISPColors.DIM);
end;

procedure TGRISPTUIApp.DrawExplorer;
var
  r: TTUIRect;
  i, y: Integer;
  focused: Boolean;
  perms: set of Byte;
begin
  if FLeftCollapsed then Exit;
  focused := FFocused = fpExplorer;
  r := TTUIRect.Create(1,4,38,14);
  DrawBox(r, 'Explorer - R W X', focused);

  for i := 0 to High(FExplorer) do
  begin
    if i > 10 then Break;
    y := r.Y + 1 + i;
    if y >= r.Y + r.H - 1 then Break;

    if i = FSelExplorer then
    begin
      GotoXY(r.X+1, y);
      SetColor(TGRISPColors.CYAN_BG + TGRISPColors.WHITE);
      Write(StringOfChar(' ', r.W-2));
    end;

    DrawText(r.X + 2 + FExplorer[i].Level*2, y, FExplorer[i].Name, '');
    // R W X
    perms := [];
    if 0 in FExplorer[i].Perms then Include(perms, 0);
    if 1 in FExplorer[i].Perms then Include(perms, 1);
    if 2 in FExplorer[i].Perms then Include(perms, 2);
    DrawRWX(r.X + r.W - 10, y, perms);
  end;
end;

procedure TGRISPTUIApp.DrawSessions;
var
  r: TTUIRect;
  i, y: Integer;
  focused: Boolean;
  line: string;
begin
  if FLeftCollapsed then Exit;
  focused := FFocused = fpSessions;
  r := TTUIRect.Create(1,18,38,10);
  DrawBox(r, 'Sessions - Subject + Day + Time', focused);
  for i := 0 to High(FSessions) do
  begin
    y := r.Y + 1 + i;
    if y >= r.Y + r.H - 1 then Break;
    if i = FSelSession then
    begin
      GotoXY(r.X+1, y);
      SetColor(TGRISPColors.CYAN_BG + TGRISPColors.WHITE);
      Write(StringOfChar(' ', r.W-2));
    end;
    line := Copy(FSessions[i].Subject,1,18);
    DrawText(r.X+2, y, line, '');
    DrawText(r.X+22, y, FSessions[i].Day + ' ' + FSessions[i].TimeStr, TGRISPColors.DIM);
  end;
  DrawText(r.X+2, r.Y+r.H-1, '+ New Session', TGRISPColors.GREEN);
end;

procedure TGRISPTUIApp.DrawChat;
var
  r, tr: TTUIRect;
  focused: Boolean;
  y: Integer;
  i: Integer;
  leftW: Integer;
  rightW: Integer;
begin
  focused := FFocused = fpChat;
  leftW := 1; if not FLeftCollapsed then leftW := 39;
  rightW := 0; if not FRightCollapsed then rightW := 36;
  r := TTUIRect.Create(leftW, 4, FWidth - leftW - rightW - 1, FHeight - 12);

  DrawBox(r, 'Chat: Project setup and architecture', focused);

  y := r.Y + 1;
  for i := 0 to High(FChat) do
  begin
    if y > r.Y + r.H - 6 then Break;
    if FChat[i].Role = crUser then
      DrawText(r.X+2, y, 'You [' + FChat[i].TimeStr + ']: ' + Copy(FChat[i].Text,1, r.W-20), TGRISPColors.BLUE)
    else
      DrawText(r.X+2, y, 'GRISP [' + FChat[i].TimeStr + ']: ' + Copy(FChat[i].Text,1, r.W-20), TGRISPColors.WHITE);
    Inc(y);
    // Show first line of text
    if Length(FChat[i].Text) > 50 then
    begin
      DrawText(r.X+4, y, Copy(FChat[i].Text, 50, r.W-10), TGRISPColors.DIM);
      Inc(y);
    end;

    // Think window - collapsable
    if (FChat[i].Thinking <> '') and FThinkExpanded then
    begin
      tr := TTUIRect.Create(r.X+2, y, r.W-4, 4);
      DrawBox(tr, 'Thinking - 3 steps [T]oggle', FFocused = fpThink);
      DrawText(tr.X+2, tr.Y+1, '✓ Analyzing architecture...', TGRISPColors.GREEN);
      DrawText(tr.X+2, tr.Y+2, '✓ Identified 7 components...', TGRISPColors.GREEN);
      y := tr.Y + tr.H;
    end;
    Inc(y);
  end;

  if FChat[High(FChat)].HasPlan then
  begin
    DrawText(r.X+2, y, '[Plan embedded: 4 steps - see right panel]', TGRISPColors.CYAN);
  end;
end;

procedure TGRISPTUIApp.DrawPlan;
var
  r: TTUIRect;
  i, y: Integer;
  focused: Boolean;
  status, prio: string;
begin
  if FRightCollapsed then Exit;
  focused := FFocused = fpPlan;
  r := TTUIRect.Create(FWidth - 35, 4, 35, FHeight - 12);
  DrawBox(r, 'Plan / Work Items', focused);

  y := r.Y + 1;
  for i := 0 to High(FPlan) do
  begin
    if y >= r.Y + 8 then Break;
    case FPlan[i].Status of
      0: status := '[ ]';
      1: status := '[○]';
      2: status := '[✓]';
    end;
    if i = FSelPlan then
    begin
      GotoXY(r.X+1, y);
      SetColor(TGRISPColors.CYAN_BG + TGRISPColors.WHITE);
      Write(StringOfChar(' ', r.W-2));
    end;
    DrawText(r.X+2, y, status + ' ' + Copy(FPlan[i].Title,1,18), '');
    Inc(y);
  end;

  DrawHLine(r.X+1, y, r.W-2, False);
  Inc(y);
  DrawText(r.X+2, y, 'Work Items:', TGRISPColors.WHITE);
  Inc(y);

  for i := 0 to High(FWorkItems) do
  begin
    if y >= r.Y + r.H - 2 then Break;
    case FWorkItems[i].Priority of
      0: prio := '[Low]';
      1: prio := '[Med]';
      2: prio := '[High]';
    end;
    DrawText(r.X+2, y, Copy(FWorkItems[i].Title,1,18), '');
    if FWorkItems[i].Priority = 2 then
      DrawText(r.X+22, y, prio, TGRISPColors.RED)
    else if FWorkItems[i].Priority = 1 then
      DrawText(r.X+22, y, prio, TGRISPColors.AMBER)
    else
      DrawText(r.X+22, y, prio, TGRISPColors.BLUE);
    Inc(y);
  end;

  DrawText(r.X+2, r.Y+r.H-2, '[Space] Complete [C] Collapse', TGRISPColors.DIM);
end;

procedure TGRISPTUIApp.DrawInput;
var
  r: TTUIRect;
begin
  r := TTUIRect.Create(1, FHeight-7, FWidth, 4);
  DrawBox(r, 'Input - Type message, Enter to send', FFocused = fpInput);
  DrawText(r.X+2, r.Y+1, 'GRISP> ' + FInputBuffer + '█', TGRISPColors.WHITE);
  DrawText(r.X+2, r.Y+2, '[Tab] Switch panel  [T] Think  [C] Collapse  [F10/Q] Quit  [Arrows] Navigate', TGRISPColors.DIM);
end;

procedure TGRISPTUIApp.DrawFooter;
begin
  DrawText(1, FHeight-2, Format(' ACTIVE: GRISP://Workspace | R W X | Models: GPT-5 Claude | %dx%d | Focus:%d ', [FWidth, FHeight, Ord(FFocused)]), TGRISPColors.BG_PANEL + TGRISPColors.DIM);
  DrawText(1, FHeight-1, ' F1 Explorer  F2 Sessions  F3 Chat  F4 Plan  F5 Think  F10 Quit  Type in Input panel ', TGRISPColors.CYAN_DIM);
end;

function TGRISPTUIApp.ReadKey: Word;
var
  ir: TInputRecord;
  num: DWORD;
  hIn: THandle;
begin
  hIn := GetStdHandle(STD_INPUT_HANDLE);
  repeat
    ReadConsoleInput(hIn, ir, 1, num);
    if (ir.EventType = KEY_EVENT) and ir.Event.KeyEvent.bKeyDown then
    begin
      Result := ir.Event.KeyEvent.wVirtualKeyCode;
      // Handle char input for Input panel
      if FFocused = fpInput then
      begin
        if ir.Event.KeyEvent.uChar.AsciiChar >= #32 then
          FInputBuffer := FInputBuffer + ir.Event.KeyEvent.uChar.AsciiChar
        else if ir.Event.KeyEvent.wVirtualKeyCode = VK_BACK then
          if Length(FInputBuffer) > 0 then
            SetLength(FInputBuffer, Length(FInputBuffer)-1);
      end;
      Exit;
    end;
  until False;
end;

procedure TGRISPTUIApp.HandleInput;
var
  key: Word;
begin
  key := ReadKey;
  case key of
    VK_F1: FFocused := fpExplorer;
    VK_F2: FFocused := fpSessions;
    VK_F3: FFocused := fpChat;
    VK_F4: FFocused := fpPlan;
    VK_F5: ToggleThink;
    VK_F10, Ord('Q'): FRunning := False;
    VK_TAB:
      begin
        if GetKeyState(VK_SHIFT) < 0 then
          FFocused := TFocusedPanel((Ord(FFocused) - 1 + 6) mod 6)
        else
          FFocused := TFocusedPanel((Ord(FFocused) + 1) mod 6);
      end;
    VK_UP: MoveSelection(-1);
    VK_DOWN: MoveSelection(1);
    VK_RETURN:
      begin
        if FFocused = fpInput then
          SendCurrentInput
        else if FFocused = fpPlan then
        begin
          // Toggle plan status
          if (FSelPlan <= High(FPlan)) then
            FPlan[FSelPlan].Status := (FPlan[FSelPlan].Status + 1) mod 3;
        end;
      end;
    Ord('T'), Ord('t'): ToggleThink;
    Ord('C'), Ord('c'):
      begin
        if FFocused in [fpExplorer, fpSessions] then ToggleLeft
        else if FFocused = fpPlan then ToggleRight;
      end;
  end;
end;

procedure TGRISPTUIApp.MoveSelection(Delta: Integer);
begin
  case FFocused of
    fpExplorer:
      begin
        FSelExplorer := FSelExplorer + Delta;
        if FSelExplorer < 0 then FSelExplorer := 0;
        if FSelExplorer > High(FExplorer) then FSelExplorer := High(FExplorer);
      end;
    fpSessions:
      begin
        FSelSession := FSelSession + Delta;
        if FSelSession < 0 then FSelSession := 0;
        if FSelSession > High(FSessions) then FSelSession := High(FSessions);
      end;
    fpPlan:
      begin
        FSelPlan := FSelPlan + Delta;
        if FSelPlan < 0 then FSelPlan := 0;
        if FSelPlan > High(FPlan) then FSelPlan := High(FPlan);
      end;
  end;
end;

procedure TGRISPTUIApp.ToggleLeft;
begin
  FLeftCollapsed := not FLeftCollapsed;
end;

procedure TGRISPTUIApp.ToggleRight;
begin
  FRightCollapsed := not FRightCollapsed;
end;

procedure TGRISPTUIApp.ToggleThink;
begin
  FThinkExpanded := not FThinkExpanded;
end;

procedure TGRISPTUIApp.SendCurrentInput;
var
  msg: TChatMessage;
begin
  if Trim(FInputBuffer) = '' then Exit;
  msg.Role := crUser;
  msg.Text := FInputBuffer;
  msg.TimeStr := FormatDateTime('hh:nn', Now);
  msg.Thinking := '';
  msg.HasPlan := False;

  SetLength(FChat, Length(FChat)+1);
  FChat[High(FChat)] := msg;

  // Simulate assistant response with think
  msg.Role := crAssistant;
  msg.Text := 'Begrepen: "' + FInputBuffer + '" -> via SIR -> Planner -> Evaluator. R W X gevalideerd.';
  msg.Thinking := 'Analyzing: ' + FInputBuffer + sLineBreak + '✓ Parsed' + sLineBreak + '✓ Planned';
  msg.HasPlan := True;
  SetLength(FChat, Length(FChat)+1);
  FChat[High(FChat)] := msg;

  FInputBuffer := '';
  FFocused := fpChat;
end;

procedure TGRISPTUIApp.Run;
begin
  ClearScreen;
  while FRunning do
  begin
    DrawAll;
    HandleInput;
  end;
  ClearScreen;
  ResetColor;
  ShowCursor;
  Writeln('GRISP TUI gesloten. Bedankt!');
end;

end.
